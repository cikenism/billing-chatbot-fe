(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@supabase_node-fetch_browser_3a64eb90.js",
  "static/chunks/node_modules_09456698._.js",
  "static/chunks/src_21594bcb._.js"
],
    source: "dynamic"
});
