(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@supabase_node-fetch_browser_6566d8c9.js",
  "static/chunks/node_modules_c93f3d2b._.js",
  "static/chunks/src_21594bcb._.js"
],
    source: "dynamic"
});
