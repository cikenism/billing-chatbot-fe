(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_globals_b805903d.css",
  "static/chunks/node_modules_@supabase_node-fetch_browser_4ce29bfb.js",
  "static/chunks/node_modules_716cdf34._.js",
  "static/chunks/src_ad7e4e65._.js"
],
    source: "dynamic"
});
