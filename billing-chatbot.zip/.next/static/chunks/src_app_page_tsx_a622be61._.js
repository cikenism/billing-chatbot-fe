(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@supabase_node-fetch_browser_09bbbbfe.js",
  "static/chunks/node_modules_95b5f0cc._.js",
  "static/chunks/src_4e9d002c._.js"
],
    source: "dynamic"
});
