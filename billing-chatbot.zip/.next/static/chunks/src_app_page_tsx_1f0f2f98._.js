(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@supabase_node-fetch_browser_4e7450c2.js",
  "static/chunks/node_modules_0f1da435._.js",
  "static/chunks/src_4e9d002c._.js"
],
    source: "dynamic"
});
