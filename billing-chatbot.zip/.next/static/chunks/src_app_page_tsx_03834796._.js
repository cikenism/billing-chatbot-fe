(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_496f4b2c._.js",
  "static/chunks/src_f4e3b238._.js"
],
    source: "dynamic"
});
